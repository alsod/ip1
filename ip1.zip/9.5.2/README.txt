Starta NotATrojan med "java -jar NotATrojan.jar <port> <password> <mailadress>"
(notera att mappen lib m�ste vara i samma mapp som jar-filen)

Starta NotATrojanClient med "java -jar NotATrojanClient.jar <adress> <port> <l�senord>"